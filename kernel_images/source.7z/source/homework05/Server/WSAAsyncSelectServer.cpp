// WSAAsyncSelectServer.cpp : Defines the entry point for the application.

#include "WSAAsyncSelectServer.h"
#include "winsock2.h"
#include "windows.h"
#include <WS2tcpip.h>
#include "stdio.h"
#include "conio.h"
#include <time.h>
#include <stdlib.h>

#define WM_SOCKET WM_USER + 1
#define SERVER_PORT 6000
#define SERVER_ADDR "127.0.0.1"
#define MAX_CLIENT 1024
#define BUFF_SIZE 2048

#pragma warning(disable:4996)
#pragma comment(lib, "Ws2_32.lib")

void processData(struct DATA* [], struct DATA*, char*, char*);
int loginSession(struct DATA* [], struct DATA*, char*);
int postSession(struct DATA*, char*);
int logoutSession(struct DATA*);
char* getTime();
int checkUser(char*);
void writeLog(int, struct DATA*, int);

/* Struct data socket
* sock: stores the socket's identify
* ip: stores the string address of client
* port: store the number port of client address
* user: identify name of client connected
* post: if client post is the message at the current access
* stt_login: status of client (login or logout)
*/
struct DATA {
	SOCKET sock;
	char ip[INET_ADDRSTRLEN];
	int port;
	char user[256];
	char post[BUFF_SIZE];
	bool stt_login;
};

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
HWND				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	windowProc(HWND, UINT, WPARAM, LPARAM);

SOCKET client[MAX_CLIENT];
SOCKET listenSock;
//struct client
struct DATA* nclients[MAX_CLIENT];

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{

	MSG msg;
	HWND serverWindow;

	//Registering the Window Class
	MyRegisterClass(hInstance);

	//Create the window
	if ((serverWindow = InitInstance(hInstance, nCmdShow)) == NULL)
		return FALSE;

	//Initiate WinSock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		MessageBox(serverWindow, L"Winsock 2.2 is not supported.", L"Error!", MB_OK);
		return 0;
	}

	//Construct socket	
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//requests Windows message-based notification of network events for listenSock
	WSAAsyncSelect(listenSock, serverWindow, WM_SOCKET, FD_ACCEPT | FD_CLOSE | FD_READ);

	//Bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);
	
	
	for (int i = 0; i < FD_SETSIZE; i++)
	{
		nclients[i] = (struct DATA*)malloc(sizeof(struct DATA));
	}

	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		MessageBox(serverWindow, L"Cannot associate a local address with server socket.", L"Error!", MB_OK);
	}

	//Listen request from client
	if (listen(listenSock, MAX_CLIENT)) {
		MessageBox(serverWindow, L"Cannot place server socket in state LISTEN.", L"Error!", MB_OK);
		return 0;
	}

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return 0;
}


//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = windowProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WSAASYNCSELECTSERVER));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = L"WindowClass";
	wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
HWND InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	HWND hWnd;
	int i;
	for (i = 0; i < MAX_CLIENT; i++)
		client[i] = 0;
	hWnd = CreateWindow(L"WindowClass", L"WSAAsyncSelect TCP Server", WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	if (!hWnd)
		return FALSE;

	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	return hWnd;
}

//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_SOCKET	- process the events on the sockets
//  WM_DESTROY	- post a quit message and return
//
//

LRESULT CALLBACK windowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	SOCKET connSock;
	sockaddr_in clientAddr;
	int ret, clientAddrLen = sizeof(clientAddr), i;
	char rcvBuff[BUFF_SIZE], sendBuff[BUFF_SIZE];

	switch (message) {
	case WM_SOCKET:
	{
		if (WSAGETSELECTERROR(lParam)) {
			for (i = 0; i < MAX_CLIENT; i++)
				if (client[i] == (SOCKET)wParam) {
					closesocket(client[i]);
					client[i] = 0;

					// clears login status when user disconnects
					nclients[i]->stt_login = 0;
					memset(nclients[i]->user, 0, sizeof(nclients[i]->user));
					continue;
				}
		}

		switch (WSAGETSELECTEVENT(lParam)) {
		case FD_ACCEPT:
		{
			connSock = accept((SOCKET)wParam, (sockaddr*)&clientAddr, &clientAddrLen);
			if (connSock == INVALID_SOCKET) {
				break;
			}
			for (i = 0; i < MAX_CLIENT; i++)
				if (client[i] == 0) {
					client[i] = connSock;
					nclients[i]->sock = connSock;	// struct data
					sprintf(nclients[i]->ip, "%s", inet_ntoa(clientAddr.sin_addr));		// get client's IP
					nclients[i]->port = ntohs(clientAddr.sin_port);						// get client's Port

					break;
					//requests Windows message-based notification of network events for listenSock
					WSAAsyncSelect(client[i], hWnd, WM_SOCKET, FD_READ | FD_CLOSE);
				}
			if (i == MAX_CLIENT)
				MessageBox(hWnd, L"Too many clients!", L"Notice", MB_OK);
		}
		break;

		case FD_READ:
		{
			for (i = 0; i < MAX_CLIENT; i++)
				if (client[i] == (SOCKET)wParam)
					break;
			memset(rcvBuff, 0, sizeof(rcvBuff));
			ret = recv(client[i], rcvBuff, BUFF_SIZE, 0);
			if (ret > 0) {
				memset(sendBuff, 0, sizeof(sendBuff));
				processData(nclients, nclients[i], rcvBuff, sendBuff);		// process data receive from client
				send(client[i], sendBuff, sizeof(sendBuff), 0);
			}
		}
		break;

		case FD_CLOSE:
		{
			for (i = 0; i < MAX_CLIENT; i++)
				if (client[i] == (SOCKET)wParam) {
					closesocket(client[i]);
					client[i] = 0;

					// fclose
					nclients[i]->stt_login = 0;
					memset(nclients[i]->user, 0, sizeof(nclients[i]->user));
					break;
				}
		}
		break;
		}
	}
	break;

	case WM_DESTROY:
	{
		PostQuitMessage(0);
		shutdown(listenSock, SD_BOTH);
		closesocket(listenSock);
		WSACleanup();
		return 0;
	}
	break;

	case WM_CLOSE:
	{
		DestroyWindow(hWnd);
		shutdown(listenSock, SD_BOTH);
		closesocket(listenSock);
		WSACleanup();
		return 0;
	}
	break;
	}
	return DefWindowProc(hWnd, message, wParam, lParam);
}


/* my protocol like this:
LOGIN		10: Login successed
			11: User does not exit
			12: User is blocked
			13: User is logged in other device
			14: You have not logged out
----------------------------------------------------
POST		20: Post successed
			21: You have not logged in
----------------------------------------------------
LOGOUT		30: Log out successed
			31: You have not logged in
*/

/* The processData function copies the input string to output
* @param in Pointer to input string
* @param out Pointer to output string
* @return No return value
*/
void processData(struct DATA* nclients[], struct DATA* client, char* in, char* out) {
	char c = in[0];
	int code_error;
	switch (c)
	{
	case '1':	// login
		code_error = loginSession(nclients, client, &in[1]);
		writeLog(1, client, code_error);
		break;
	case '2': // post
		code_error = postSession(client, &in[1]);
		writeLog(2, client, code_error);
		break;
	case '3': // logout
		code_error = logoutSession(client);
		writeLog(3, client, code_error);
		break;
	default:	// otherwise
		break;
	}
	sprintf(out, "%d", code_error);
}

/* The getTime function get the time at the current time
* No param
* @return: string date/mounth/year and hour/min/sec at the time the function is called
*/
char* getTime()
{
	char* str_time;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	str_time = (char*)malloc(256);
	sprintf(str_time, "%d/%0d/%0d %02d:%02d:%02d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);

	return str_time;
}

/* The loginSession function is processed when a user wants to login PostRoom
* @param1: struct DATA* nclients[] is a list of clients connected server
* @param2: struct DATA* clients is a client connected in this session
* @param3: char* buff is a buffer which is stored client's data
* @return: The function return code error when user is logged in or otherwise
*/
int loginSession(struct DATA* nclients[], struct DATA* client, char* buff)
{
	memset(client->user, 0, sizeof(client->user));

	// check if other devices login with the same user
	for (int i = 0; i < FD_SETSIZE; i++) {
		if (!strcmp(nclients[i]->user, buff))
			return 13;
	}
	// copy username from client's data to client's struct in server
	memcpy(client->user, buff, sizeof(client->user));
	if (client->stt_login == 1)
		return 14;
	int nUser = checkUser(buff);
	switch (nUser)
	{
	case 200:
		return 12;
	case 201:
		return 11;
	default:
		client->stt_login = 1;
		return 10;
	}
}

/* The postSession function is processed when user wants to post something into PostRoom
* @param1: struct DATA* client is the client's session
* @param2: char* buff is the client's data (something that client want to post, such as: status, message, etc)
* @return: this function return the code error which is defined success or fail.
*/
int postSession(struct DATA* client, char* buff)
{
	if (client->stt_login == 0)	// client have not login, so they cant post anything in PostRoom
		return 21;
	else {
		memcpy(client->post, buff, sizeof(client->post)); // stored post in client's struct 
		return 20;
	}
}

/* The logoutSession is processed when user wants to logout of this session
* @param1: struct DATA* client is the client's session
* @return: this function return code error when client logouted, like this:
* 30: success
* 31: fail (may be you dont login)
*/
int logoutSession(struct DATA* client)
{
	if (client->stt_login == 1) {
		memset(client->user, 0, sizeof(client->user));
		client->stt_login = 0;
		return 30;
	}
	else
		return 31;
}

/* The checkUser function is processed when user login. It checks the user in the database
* and the current status of that account
* @param1: char*name is the buffer that stored username
* @return: code error of account that i want to check, like this:
* 201: this account dont exist
* 200: this account is blocked
* other: this account exists and dont blocked
*/
int checkUser(char* name)
{
	char str[100];
	int i = 0;
	FILE* acc = fopen("account.txt", "r");

	if (acc == NULL) {
		puts("Error while opening the file");
		exit(1);
	}

	// read all user in file
	while (fgets(str, 256, acc) != NULL)
	{
		if (memcmp(str, name, strlen(name)) == 0) {
			fclose(acc);
			if (str[strlen(name) + 1] == '1')
				return i;
			else
				return 200;
		}
		i++;
	}
	fclose(acc);
	return 201;
}

/* The writeLog function writes log into file name log_20183781.txt (this is my studentID)
* @param1: define type of log
* @param2: struct DATA* client is client's session
* @param3: int code_error is the status code
* @return: this function not return value
*/
void writeLog(int log, struct DATA* client, int code_error)
{
	FILE* hlog = fopen("log_20183781.txt", "a+");
	switch (log)
	{
	case 1: // login
		fprintf(hlog, "%s:%d [%s] $ LOGIN %s $ %d\n", client->ip, client->port, getTime(), client->user, code_error);
		break;
	case 2:	// post
		fprintf(hlog, "%s:%d [%s] $ POST %s $ %d\n", client->ip, client->port, getTime(), client->post, code_error);
		break;
	case 3: // logout
		fprintf(hlog, "%s:%d [%s] $ LOGOUT $ %d\n", client->ip, client->port, getTime(), code_error);
		break;
	default: // exception	
		break;
	}
	fclose(hlog);
}