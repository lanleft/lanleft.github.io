// MultiThreadTCPServer.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <WS2tcpip.h>
#include <WinSock2.h>
#include <process.h>
#include <synchapi.h>

#define BUFF_SIZE 2048
#define SERVER_ADDR "127.0.0.1"

#pragma comment(lib, "WS2_32.lib")
#pragma warning(disable:4996)

// struct socket data
struct DATA {
	SOCKET sock;
	char ip[INET_ADDRSTRLEN];
	int port;
	char user[256];
	bool stt_login;
};

// global variables
char clientIP[INET_ADDRSTRLEN];
int clientPort;
HANDLE mutex[20];

// check user exit 
int checkUser(char* name)
{
	char str[100];
	int i = 0;
	FILE* acc = fopen("account.txt", "r");

	if (acc == NULL) {
		puts("Error while opening the file");
		exit(1);
	}

	// read all user in file
	while (fgets(str, 256, acc) != NULL)
	{
		if (memcmp(str, name, strlen(name)) == 0) {
			fclose(acc);
			if (str[strlen(name) + 1] == '1')
				return i;
			else
				return 200;
		}
		i++;
	}
	fclose(acc);
	return 201;
}
// get real time 
char* getTime()
{
	char *str_time;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	str_time = (char*)malloc(256);
	sprintf(str_time, "%d/%0d/%0d %02d:%02d:%02d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);

	return str_time;
}

/* list error code 

LOGIN		10: Login successed
			11: User does not exit
			12: User is blocked
			13: User is logged in other device
			14: You have not logged out 
----------------------------------------------------
POST		20: Post successed
			21: You have not logged in
----------------------------------------------------
LOGOUT		30: Log out successed
			31: You have not logged in

*/

// echoThread - Thread to receive the message from client and echo 
unsigned __stdcall echoThread(void* param)
{
	char buff[BUFF_SIZE], code_error[4];
	int ret, nUser, waitStt;
	struct DATA* client;
	client = (DATA*)malloc(sizeof(DATA));

	// clean data
	memset(client->ip, 0, INET_ADDRSTRLEN);
	memset(client->user, 0, 256);
	memset(code_error, 0, 4);
	client->stt_login = 0;

	// set data
	memcpy(client->ip, clientIP, strlen(clientIP));
	client->port = clientPort;
	client->sock = (SOCKET)param;

	// log file 
	FILE *hlog = fopen("log_20183781.txt", "a+");

	while (1) {
		// clean data 
		memset(buff, 0, BUFF_SIZE);
		ret = recv(client->sock, buff, BUFF_SIZE, 0);

		if (ret == SOCKET_ERROR) {
			printf("Error %d: Cannot receive data\n", WSAGetLastError());
			fclose(hlog);
			return 0;
		}
		else if (ret == 0) {
			printf("Client disconnected!\n");
			fclose(hlog);
			return 0;
		}
		else if (strlen(buff) > 0) {
			buff[ret] = 0;

			// login session
			if (buff[0] == '1') {
				if (client->stt_login == 1) {
					memcpy(code_error, "14", 2);
				}

				else {
					nUser = checkUser(buff + 1);
					if (nUser == 200)
						memcpy(code_error, "12", 2); 
					else if (nUser == 201)
						memcpy(code_error, "11", 2);
					else {									
						waitStt = WaitForSingleObject(mutex[nUser], NULL);
						if (waitStt == WAIT_OBJECT_0) {
							memcpy(code_error, "10", 2);
							client->stt_login = 1;
							memcpy(client->user, buff + 1, strlen(buff + 1));
						}
						else
							memcpy(code_error, "13", 2);						
					}
						
				}
				fprintf(hlog, "%s:%d [%s] $ LOGIN %s $ %s\n", client->ip, client->port, getTime(), client->user, code_error);
			}
			// post message
			else if (buff[0] == '2') {
				if (client->stt_login == 0)
					memcpy(code_error, "21", 2);
				else
					memcpy(code_error, "20", 2);

				fprintf(hlog, "%s:%d [%s] $ POST %s $ %s\n", client->ip, client->port, getTime(), buff+1, code_error);
			}

			else if (buff[0] == '3') {
				if (client->stt_login == 1) {
					memcpy(code_error, "30", 2);
					memset(client->user, 0, sizeof(client->user));
					client->stt_login = 0;
					ReleaseMutex(mutex);
				}
				else
					memcpy(code_error, "31", 2);

				fprintf(hlog, "%s:%d [%s] $ LOGOUT $ %s\n", client->ip, client->port, getTime(), code_error);
			}

			// echo to client 
			ret = send(client->sock, code_error, 2, 0);
			if (ret == SOCKET_ERROR) {
				printf("Error %d: Cannot send data\n", WSAGetLastError());
				return 0;
			}
		}
		}
		closesocket(client->sock);
		fclose(hlog);
		return 0;
	}

	int main(int argc, char* argv[])
	{
		if (argc != 2) {
			puts("Usage: server.exe [number_port] \n");
			return 0;
		}
		int SERVER_PORT = atoi(argv[1]);

		// step 1: init socket
		WSADATA wsaData;
		WORD wVersion = MAKEWORD(2, 2);
		if (WSAStartup(wVersion, &wsaData)) {
			printf("Winsock ver2.2 not supported \n");
			return 0;
		}

		// step 2: construct socket
		SOCKET listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

		// step 3: bind address to socket
		sockaddr_in serverAddr;
		serverAddr.sin_family = AF_INET;
		serverAddr.sin_port = htons(SERVER_PORT);
		inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);

		if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr))) {
			printf("Error %d: Cannot associate a local address with server socket\n", WSAGetLastError());
			return 0;
		}

		// step 4: listen request from clients
		if (listen(listenSock, 10)) {
			printf("Error %d: Cannot place server socket in state LISTEN\n", WSAGetLastError());
			return 0;
		}

		printf("Server started!\n");

		// step 5: commicate with client
		SOCKET connSocket;
		sockaddr_in clientAddr;
		int clientAddrLen = sizeof(clientAddr);
		
		// mutex
		for (int i = 0; i < 20; i++)
			mutex[i] = CreateMutex(NULL, FALSE, NULL);

		while (1) {
			connSocket = accept(listenSock, (sockaddr*)&clientAddr, &clientAddrLen);
			if (connSocket == SOCKET_ERROR)
				printf("Error %d: Cannot permit incomming connection\n", WSAGetLastError());
			else {
				inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
				clientPort = ntohs(clientAddr.sin_port);

				printf("Accept incomming connection from %s:%d\n", clientIP, clientPort);
				_beginthreadex(0, 0, echoThread, (void*)connSocket, 0, 0); // start thread
			}
		}

		closesocket(listenSock);

		WSACleanup();

		return 0;

	}