#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
// #define SERVER_PORT 8080
#define SERVER_ADDR "127.0.0.1"
#define BUFF_SIZE 2048
#pragma comment(lib, "Ws2_32.lib")

#pragma warning(disable:4996)

// function check input is ipv4 or domain
// True = IPv4, Flase = domain
bool checkAddr(char* s)
{
	int dot = 0;
	for (int i = 0; i < strlen(s); i++) {
		if ((char)*(s + i) == 46) dot++;
	}
	// printf("%d\n", dot);
	if (dot == 3) return true;
	return false;
}

char* getInfoIP(char* s)
{
	char infoVal[BUFF_SIZE], servInfo[NI_MAXSERV], hostname[NI_MAXHOST];
	char valTmp[BUFF_SIZE];
	sockaddr_in sa;
	int errcode;

	sa.sin_family = AF_INET;
	sa.sin_addr.s_addr = inet_addr(s);
	
	errcode = getnameinfo((sockaddr*)&sa, sizeof(sockaddr), hostname, NI_MAXHOST, servInfo, NI_MAXSERV, NI_NUMERICSERV);

	// clear mem
	memset(infoVal, 0, BUFF_SIZE);
	memset(valTmp, 0, BUFF_SIZE);

	// get info
	if (errcode != 0) {
		printf("getnameinfo faild with error %d\n", WSAGetLastError());
		memcpy(infoVal, "-Not found!\n", 13);
		return infoVal;
	}
	else {
		infoVal[0] = '+';
		char* index = infoVal + 1;
		printf("Official name: %s\n", hostname);

		memset(valTmp, 0, BUFF_SIZE);
		sprintf(valTmp, "Official name: %s\n", hostname);
		memmove(index, valTmp, strlen(valTmp));
		index += strlen(valTmp);

		/*index++;
		for (pAlias = remoteHost->h_aliases; *pAlias != 0; pAlias++) {
			printf("Alternate name: %s\n", *pAlias);
			memmove(index, *pAlias, strlen(*pAlias));
			index += strlen(*pAlias);
			memmove(index, "\n", 1);
			index++;
		}*/
		return infoVal;
	}
}

char* getInfoDomain(char* s)
{
	// setup the hints address info structure which is passed to the getaddrinfo() fucntion
	addrinfo* result = NULL;
	addrinfo* ptr = NULL;
	addrinfo hints;

	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	//hints.ai_protocol = IPPROTO_UDP;
	int errcode;

	// contain return value
	sockaddr_in *addrv4;
	char infoVal[BUFF_SIZE], addrIP[BUFF_SIZE];
	char valTmp[BUFF_SIZE];
	
	// call getaddrinfo()			
	errcode = getaddrinfo(s, NULL, &hints, &result);

	// clear mem
	memset(valTmp, 0, BUFF_SIZE);
	memset(infoVal, 0, BUFF_SIZE);

	// check
	if (errcode != 0) {
		printf("Getaddrinfo faild with error code: %d\n", errcode);
		memcpy(infoVal, "-Not found infomation!\n", 24);
		printf("%s\n", infoVal);
		return infoVal;
	}
	else {
		infoVal[0] = '+';
		char* tmp = &infoVal[1];
		int i = 1;
		for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {

			addrv4 = (sockaddr_in*)ptr->ai_addr;
			inet_ntop(AF_INET, &addrv4->sin_addr, addrIP, sizeof(addrIP));
			if (i != 1) printf("Official IP: %s\n", addrIP);
			else printf("Official IP: %s\n", addrIP);

			memset(valTmp, 0, BUFF_SIZE);

			if (i != 1) sprintf(valTmp, "Alias IP: %s\n", addrIP);
			else sprintf(valTmp, "Official IP: %s\n", addrIP);

			// move address
			memmove(tmp, valTmp, strlen(valTmp));
			tmp += strlen(valTmp);
			i++;
		}
		return infoVal;
	}
}

int main(int argc, char* argv[])
{
	// define value
	int SERVER_PORT = 0;

	if (argc != 2) {
		printf("Usage: server.exe [server_port]\n");
		return 0;
	}
	// parser argument
	SERVER_PORT = atoi(argv[1]);

	// Init winsock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		printf("Winsock 2.2 is not supported\n");
		return 0;
	}

	// construct socket
	SOCKET server;
	server = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (server == INVALID_SOCKET) {
		printf("Error %d: Cannot create server socket.\n", WSAGetLastError());
		return 0;
	}

	// bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);
	if (bind(server, (sockaddr*)&serverAddr, sizeof(serverAddr))) {
		printf("Error %d: Cannot bind this address.\n", WSAGetLastError());
		getchar();
		return 0;
	}

	printf("Server started!\n");

	// communicate with client
	sockaddr_in clientAddr;
	char buff[BUFF_SIZE], clientIP[INET_ADDRSTRLEN];
	int ret, clientAddrLen = sizeof(clientAddr), clientPort;

	char retinfo[256];
	char* rv;

	while (1) {
		// receive message
		ret = recvfrom(server, buff, BUFF_SIZE, 0, (sockaddr*)&clientAddr, &clientAddrLen);
		if (ret == SOCKET_ERROR) {
			printf("Error %d: Cannot receive data.\n", WSAGetLastError());
		}
		else if (strlen(buff) > 0) {
			buff[ret] = 0;
			inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
			clientPort = ntohs(clientAddr.sin_port);
			printf("Receive from client[%s:%d] %s\n", clientIP, clientPort, buff);

			//printf("ok");
			// check input 
			memset(retinfo, 0, 256);
			if (checkAddr(buff)) {
				printf("domain\n");
				rv = (char*)getInfoIP(buff);
			}
			else rv = (char*)getInfoDomain(buff);

			// get address info from getInfo function
			memcpy(retinfo, rv, strlen(rv));
			// printf("%s\n", retinfo);

			// echo to clinet
			ret = sendto(server, retinfo, strlen(retinfo), 0, (sockaddr*)&clientAddr, sizeof(clientAddr));
			if (ret == SOCKET_ERROR) {
				printf("Error %d: Cannot send data\n", WSAGetLastError());
			}
		}
	}
	
	// end while

	closesocket(server);

	// terminate winsock
	WSACleanup();

	return 0;
}