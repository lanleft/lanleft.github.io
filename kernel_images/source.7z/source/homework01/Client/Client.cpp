#include "stdio.h"
#include "winsock2.h"
#include "ws2tcpip.h"
// #define SERVER_PORT 8080
// #define SERVER_ADDR "127.0.0.1"
#define BUFF_SIZE 2048
#pragma comment(lib, "Ws2_32.lib")

int main(int argc, char* argv[])
{
	// define value 
	char SERVER_ADDR[256];
	int SERVER_PORT = 0;

	// check
	if (argc != 3) {
		printf("Usage: client.exe [server_addr] [number_port]\n");
		return 0;
	}
	// parser argument
	memset(SERVER_ADDR, 0, 256);
	memcpy(SERVER_ADDR, argv[1], strlen(argv[1]));
	SERVER_PORT = atoi(argv[2]);

	// init winsock 
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		printf("Winsock 2.2 is not supported\n");
		return 0;
	}

	// construct socket
	SOCKET client;
	client = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (client == INVALID_SOCKET) {
		printf("Error %d: Cannot create server socket\n", WSAGetLastError());
		return 0;
	}

	printf("Client started!\n");

	// set time-out for receiving
	/*int tv = 10000; // 10s
	setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char*)(&tv), sizeof(int));*/

	// specify server address
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);

	// communicate with server
	char buff[BUFF_SIZE];
	int ret, serverAddrLen = sizeof(serverAddr), messageLen;
	while (1) {
		// send msg
		printf("Send to server: ");
		gets_s(buff, BUFF_SIZE);
		messageLen = strlen(buff);
		if (messageLen == 0) break;

		ret = sendto(client, buff, messageLen, 0, (sockaddr*)&serverAddr, serverAddrLen);
		if (ret == SOCKET_ERROR) {
			printf("Error %d: Cannot send message\n", WSAGetLastError());
		}

		// receive echo message
		ret = recvfrom(client, buff, BUFF_SIZE, 0, (sockaddr*)&serverAddr, &serverAddrLen);
		if (ret == SOCKET_ERROR) {
			if (WSAGetLastError() == WSAETIMEDOUT)
				printf("Time-out!");
			else printf("Error %d: Cannot receive message\n", WSAGetLastError());
		}
		else if (strlen(buff) > 0) {
			buff[ret] = 0;
			printf("Receive from server: \n%s------------------\n", buff);
		}
	}
	// end while 

	closesocket(client);

	// terminate winsock
	WSACleanup();

	return 0;
}