// server
#include <stdio.h>
#include <WinSock2.h>
#include <WS2tcpip.h>

// #define SERVER_PORT 8080
#define SERVER_ADDR "127.0.0.1"
#define BUFF_SIZE 1024

#pragma comment(lib, "Ws2_32.lib")

char* filter(char* buff)
{
	// define array stored data filter
	char ascii[BUFF_SIZE];
	char num[BUFF_SIZE];
	char result[BUFF_SIZE];

	// clear mem
	memset(num, 0, BUFF_SIZE);
	memset(ascii, 0, BUFF_SIZE);
	memset(result, 0, BUFF_SIZE);

	// check variable
	int chck = 0, tmp;
	char *pAscii = ascii;
	char *pNum = num;
	for (int i = 0; i < strlen(buff); i++) {
		tmp = (int)buff[i];

		// filter 0 -> 9
		if (tmp > 47 && tmp < 58) {
			*pNum = tmp;
			pNum++;
		}

		// filter A -> Z
		else if (tmp > 64 && tmp < 91) {
			*pAscii = tmp;
			pAscii++;
		}

		// filter a -> z
		else if (tmp > 96 && tmp < 123) {
			*pAscii = tmp;
			pAscii++;
		}
		// other 
		else {
			chck = 1;
			break;
		}
	}
	// if faild, return Error message
	if (chck == 1) {
		strcpy_s(result, "-Error");
		return result;
	}

	char* pTmp = result;
	// prefix '+' for success message
	memcpy(pTmp, "+", 1);
	pTmp++;
	memcpy(pTmp, ascii, strlen(ascii));
	pTmp += strlen(ascii);
	memcpy(pTmp, "\n", 1);
	memcpy(pTmp + 1, num, strlen(num));
	return result;
}


int main(int argc, char* argv[])
{
	// define value
	int SERVER_PORT = 0;

	if (argc != 2) {
		printf("Usage: server.exe [server_port]\n");
		return 0;
	}
	// parser argument
	SERVER_PORT = atoi(argv[1]);

	// initiate winsock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData)) {
		printf("winsock 2.2 not supported!\n");
		return 0;
	}

	// construct socket
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (listenSock == INVALID_SOCKET) {
		printf("Error %d: cannot create server socket\n", WSAGetLastError());
		return 0;
	}

	// bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET, SERVER_ADDR, &serverAddr.sin_addr);

	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr))) {
		printf("Error: %d cannot associate a local address with server socket\n", WSAGetLastError());
		return 0;
	}

	// communicate with client
	sockaddr_in clientAddr;
	char buff[BUFF_SIZE], clientIP[INET_ADDRSTRLEN];
	int ret, clientAddrLen = sizeof(clientAddr), clientPort;
	SOCKET connSock;
	char result_filter[BUFF_SIZE];
	char* pResult;

	while (1) {
		// listen request from client
		if (listen(listenSock, 10)) {
			printf("Error %d cannot place server socket in state listen\n", WSAGetLastError());
			return 0;
		}

		printf("Server started!\n");

		// accept request
		connSock = accept(listenSock, (sockaddr*)&clientAddr, &clientAddrLen);
		if (connSock == SOCKET_ERROR) {
			printf("Error %d: Cannot permit incoming connection\n", WSAGetLastError());
			return 0;
		}
		else {
			inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
			clientPort = ntohs(clientAddr.sin_port);
			printf("Accept incoming connection from %s:%d\n", clientIP, clientPort);
		}

		while (1) {
			// receive message from client 
			ret = recv(connSock, buff, BUFF_SIZE, 0);
			if (ret == SOCKET_ERROR) {
				printf("Error %d: cannot receive data.\n", WSAGetLastError());
				break;
			}
			else if (ret == 0) {
				printf("client [%s:%d] disconnected\n", clientIP, clientPort);
				break;
			}
			else {
				buff[ret] = 0;
				printf("receive from client [%s:%d] %s\n", clientIP, clientPort, buff);

				// filer data
				memset(result_filter, 0, BUFF_SIZE);
				pResult = filter(buff);
				strcpy_s(result_filter, pResult);

				// send client
				ret = send(connSock, result_filter, strlen(result_filter), 0);
				if (ret == SOCKET_ERROR) {
					printf("Error %d: cannot send data\n", WSAGetLastError());
					break;
				}
			}
		}
	}
	// end communicating

	// close socket
	closesocket(connSock);
	closesocket(listenSock);

	WSACleanup();

	return 0;
}