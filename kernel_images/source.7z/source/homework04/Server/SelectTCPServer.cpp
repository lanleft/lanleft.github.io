// SelectTCPServer.cpp : Defines the entry point for the console application.
//

#include <winsock2.h>
#include <stdio.h>
#include <conio.h>
#include <WS2tcpip.h>
#include <time.h>
#include <stdlib.h>

#pragma comment (lib,"ws2_32.lib")
#pragma warning(disable:4996)

#define BUFF_SIZE 2048
#define SERVER_ADDR "127.0.0.1"

void processData(struct DATA*[] , struct DATA* , char*, char*);
int Receive(SOCKET, char*, int, int);
int Send(SOCKET, char*, int, int);
int loginSession(struct DATA*[] , struct DATA*, char*);
int postSession(struct DATA*, char*);
int logoutSession(struct DATA*);
char* getTime();
int checkUser(char*);
void writeLog(int, struct DATA*, int);

/* Struct data socket
* sock: stores the socket's identify
* ip: stores the string address of client
* port: store the number port of client address
* user: identify name of client connected
* post: if client post is the message at the current access
* stt_login: status of client (login or logout)
*/
struct DATA {
	SOCKET sock;
	char ip[INET_ADDRSTRLEN];
	int port;
	char user[256];
	char post[BUFF_SIZE];
	bool stt_login;
};

/* The main function of project
* @param1: count of argument of main
* @param2: list argument of main
* @return: return number
*/
int main(int argc, char* argv[])
{
	// parser argument from commandline
	if (argc != 2) {
		puts("Usage: server.exe [number_port] \n");
		return 0;
	}
	int PORT = atoi(argv[1]);

	//Step 1: Initiate WinSock
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData))
		printf("Version is not supported\n");

	//Step 2: Construct socket	
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//Step 3: Bind address to socket
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT);
	serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDR);

	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error! Cannot bind this address.");
		_getch();
		return 0;
	}

	//Step 4: Listen request from client
	if (listen(listenSock, 10)) {
		printf("Error! Cannot listen.");
		_getch();
		return 0;
	}

	printf("Server started!\n");


	SOCKET client[FD_SETSIZE], connSock;
	struct DATA* nclients[FD_SETSIZE];
	fd_set readfds, initfds; //use initfds to initiate readfds at the begining of every loop step
	sockaddr_in clientAddr;
	int ret, nEvents, clientAddrLen;
	char rcvBuff[BUFF_SIZE], sendBuff[BUFF_SIZE];

	for (int i = 0; i < FD_SETSIZE; i++)
	{
		client[i] = 0;	// 0 indicates available entry
		nclients[i] = (struct DATA*)malloc(sizeof(struct DATA));
	}

	FD_ZERO(&initfds);
	FD_SET(listenSock, &initfds);

	//Step 5: Communicate with clients
	while (1) {
		readfds = initfds;		/* structure assignment */
		nEvents = select(0, &readfds, 0, 0, 0);
		if (nEvents < 0) {
			printf("\nError! Cannot poll sockets: %d", WSAGetLastError());
			break;
		}

		//new client connection
		if (FD_ISSET(listenSock, &readfds)) {
			clientAddrLen = sizeof(clientAddr);
			if ((connSock = accept(listenSock, (sockaddr*)&clientAddr, &clientAddrLen)) < 0) {
				printf("\nError! Cannot accept new connection: %d", WSAGetLastError());
				break;
			}
			else {
				printf("You got a connection from %s\n", inet_ntoa(clientAddr.sin_addr)); /* prints client's IP */

				int i;
				for (i = 0; i < FD_SETSIZE; i++)
					if (client[i] == 0) {
						client[i] = connSock;
						nclients[i]->sock = connSock;	// struct data
						sprintf(nclients[i]->ip, "%s", inet_ntoa(clientAddr.sin_addr));		// get client's IP
						nclients[i]->port = ntohs(clientAddr.sin_port);						// get client's Port
						FD_SET(client[i], &initfds);
						break;
					}

				if (i == FD_SETSIZE) {
					printf("\nToo many clients.");
					closesocket(connSock);
				}

				if (--nEvents == 0)
					continue; //no more event
			}
		}

		//receive data from clients
		for (int i = 0; i < FD_SETSIZE; i++) {
			if (client[i] == 0)
				continue;

			if (FD_ISSET(client[i], &readfds)) {
				memset(rcvBuff, 0, sizeof(rcvBuff));
				ret = Receive(client[i], rcvBuff, BUFF_SIZE, 0);
				if (ret <= 0) {
					FD_CLR(client[i], &initfds);
					closesocket(client[i]);
					client[i] = 0;

					// clears login status when user disconnects
					nclients[i]->stt_login = 0;
					memset(nclients[i]->user, 0, sizeof(nclients[i]->user));
				}
				else if (ret > 0) {
					memset(sendBuff, 0, sizeof(sendBuff));
					processData(nclients, nclients[i], rcvBuff, sendBuff);		// process data receive from client
					Send(client[i], sendBuff, strlen(sendBuff), 0);
				}
			}

			if (--nEvents <= 0)
				continue; //no more event
		}

	}

	closesocket(listenSock);
	WSACleanup();
	return 0;
}

/* my protocol like this:
LOGIN		10: Login successed
			11: User does not exit
			12: User is blocked
			13: User is logged in other device
			14: You have not logged out
----------------------------------------------------
POST		20: Post successed
			21: You have not logged in
----------------------------------------------------
LOGOUT		30: Log out successed
			31: You have not logged in
*/

/* The processData function copies the input string to output
* @param in Pointer to input string
* @param out Pointer to output string
* @return No return value
*/
void processData(struct DATA* nclients[], struct DATA *client, char* in, char* out) {
	char c = in[0];
	int code_error;
	switch (c)
	{
	case '1':	// login
		code_error = loginSession(nclients, client, &in[1]);
		writeLog(1, client, code_error);
		break;
	case '2': // post
		code_error = postSession(client, &in[1]);
		writeLog(2, client, code_error);
		break;
	case '3': // logout
		code_error = logoutSession(client);
		writeLog(3, client, code_error);
		break;
	default:	// otherwise
		break;
	}
	sprintf(out, "%d", code_error);
}

/* The recv() wrapper function */
int Receive(SOCKET s, char* buff, int size, int flags) {
	int n;

	n = recv(s, buff, size, flags);
	if (n == SOCKET_ERROR)
		printf("Error: %d\n", WSAGetLastError());

	return n;
}

/* The send() wrapper function*/
int Send(SOCKET s, char* buff, int size, int flags) {
	int n;

	n = send(s, buff, size, flags);
	if (n == SOCKET_ERROR)
		printf("Error: %d\n", WSAGetLastError());

	return n;
}

/* The getTime function get the time at the current time
* No param
* @return: string date/mounth/year and hour/min/sec at the time the function is called
*/
char* getTime()
{
	char* str_time;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	str_time = (char*)malloc(256);
	sprintf(str_time, "%d/%0d/%0d %02d:%02d:%02d", tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900, tm.tm_hour, tm.tm_min, tm.tm_sec);

	return str_time;
}

/* The loginSession function is processed when a user wants to login PostRoom
* @param1: struct DATA* nclients[] is a list of clients connected server 
* @param2: struct DATA* clients is a client connected in this session
* @param3: char* buff is a buffer which is stored client's data
* @return: The function return code error when user is logged in or otherwise
*/
int loginSession(struct DATA *nclients[], struct DATA *client, char* buff)
{
	memset(client->user, 0, sizeof(client->user));
	
	// check if other devices login with the same user
	for (int i = 0; i < FD_SETSIZE; i++) {
		if (!strcmp(nclients[i]->user, buff))
			return 13;
	}
	// copy username from client's data to client's struct in server
	memcpy(client->user, buff, sizeof(client->user));
	if (client->stt_login == 1)
		return 14;
	int nUser = checkUser(buff);
	switch (nUser)
	{
	case 200:
		return 12;
	case 201:
		return 11;
	default:
		client->stt_login = 1;
		return 10;
	}
}

/* The postSession function is processed when user wants to post something into PostRoom
* @param1: struct DATA* client is the client's session
* @param2: char* buff is the client's data (something that client want to post, such as: status, message, etc)
* @return: this function return the code error which is defined success or fail.
*/
int postSession(struct DATA* client, char* buff)
{
	if (client->stt_login == 0)	// client have not login, so they cant post anything in PostRoom
		return 21;
	else {
		memcpy(client->post, buff, sizeof(client->post)); // stored post in client's struct 
		return 20;
	}
}

/* The logoutSession is processed when user wants to logout of this session 
* @param1: struct DATA* client is the client's session
* @return: this function return code error when client logouted, like this:
* 30: success
* 31: fail (may be you dont login)
*/
int logoutSession(struct DATA* client)
{
	if (client->stt_login == 1) {
		memset(client->user, 0, sizeof(client->user));
		client->stt_login = 0;
		return 30;
	}
	else
		return 31;
}

/* The checkUser function is processed when user login. It checks the user in the database
* and the current status of that account
* @param1: char*name is the buffer that stored username
* @return: code error of account that i want to check, like this:
* 201: this account dont exist
* 200: this account is blocked
* other: this account exists and dont blocked
*/
int checkUser(char* name)
{
	char str[100];
	int i = 0;
	FILE* acc = fopen("account.txt", "r");

	if (acc == NULL) {
		puts("Error while opening the file");
		exit(1);
	}

	// read all user in file
	while (fgets(str, 256, acc) != NULL)
	{
		if (memcmp(str, name, strlen(name)) == 0) {
			fclose(acc);
			if (str[strlen(name) + 1] == '1')
				return i;
			else
				return 200;
		}
		i++;
	}
	fclose(acc);
	return 201;
}

/* The writeLog function writes log into file name log_20183781.txt (this is my studentID)
* @param1: define type of log
* @param2: struct DATA* client is client's session
* @param3: int code_error is the status code 
* @return: this function not return value
*/
void writeLog(int log, struct DATA* client, int code_error)
{
	FILE *hlog = fopen("log_20183781.txt", "a+");
	switch (log)
	{		
	case 1: // login
		fprintf(hlog, "%s:%d [%s] $ LOGIN %s $ %d\n", client->ip, client->port, getTime(), client->user, code_error);
		break;
	case 2:	// post
		fprintf(hlog, "%s:%d [%s] $ POST %s $ %d\n", client->ip, client->port, getTime(), client->post, code_error);
		break;
	case 3: // logout
		fprintf(hlog, "%s:%d [%s] $ LOGOUT $ %d\n", client->ip, client->port, getTime(), code_error);
		break;
	default: // exception	
		break;
	}
	fclose(hlog);
}